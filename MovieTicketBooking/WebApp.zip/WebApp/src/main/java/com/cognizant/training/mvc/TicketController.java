package com.cognizant.training.mvc;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TicketController {
	
	
	@Autowired
	private TicketService service;
	
	
	 @ModelAttribute("circleList")
	 public Map<String,String> buildState() {
	        Map<String,String> circleList = new LinkedHashMap<String,String>();
	        circleList.put("250", "King");
	        circleList.put("150", "Queen");
	                    
	        return circleList;
	    }
	
	
	@RequestMapping("/showpage")
	public String showPage(@ModelAttribute("ticket") Ticket ticket) {
		
		
		return "showpage";
	}
	
	
	@RequestMapping("/calculateCost")
	public String calculateTotalCost(@ModelAttribute("ticket") Ticket ticket,ModelMap model,BindingResult result) {
		
		double totalCoset=service.calculateTotalCost(ticket);
		
		model.addAttribute("cost", totalCoset);
		
		return "result";
	}

}
