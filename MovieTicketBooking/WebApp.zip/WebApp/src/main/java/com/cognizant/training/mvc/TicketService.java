package com.cognizant.training.mvc;

import org.springframework.stereotype.Service;

@Service
public class TicketService {
	
	
	public double calculateTotalCost(Ticket ticket) {
		
		double totalCost=0.0;
		
		totalCost= Integer.parseInt(ticket.getCircleType()) * ticket.getNoOfTickets();
		
		return totalCost;
		
	}

}
